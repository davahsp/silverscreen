/* ================================================
   SILVER SCREEN — Scheduler View
   Showtime List, Create Showtime, Showtime Detail
   ================================================ */

/* ── Showtime List ───────────────────────────────── */
function SchedulerShowtimes() {
  var { showtimes, movies, studios, navigate, toggleShowtime, getShowtimeStats, fmtCurrency, fmtDateTime, fmtTime, addToast } = useApp();
  var [filterMovie,  setFilterMovie]  = React.useState('');
  var [filterActive, setFilterActive] = React.useState('all');
  var [confirmDisable, setConfirmDisable] = React.useState(null); // showtimeId
  var [blockMsg, setBlockMsg] = React.useState('');

  var filtered = showtimes.filter(function(st){
    if (filterMovie && st.movie.id !== filterMovie) return false;
    if (filterActive === 'active'   && !st.is_active) return false;
    if (filterActive === 'inactive' && st.is_active)  return false;
    return true;
  });

  function tryDisable(st) {
    var stats = getShowtimeStats(st.id);
    if (stats.held > 0 || stats.confirmed > 0 || stats.printed > 0) {
      setBlockMsg('Showtime "' + st.movie.title + '" tidak dapat dinonaktifkan karena sudah memiliki tiket aktif (Held: ' + stats.held + ', Confirmed: ' + stats.confirmed + ', Printed: ' + stats.printed + ').');
      return;
    }
    setConfirmDisable(st.id);
  }

  function handleDisable() {
    toggleShowtime(confirmDisable);
    addToast('Showtime berhasil dinonaktifkan', 'success');
    setConfirmDisable(null);
  }

  function handleEnable(stId) {
    toggleShowtime(stId);
    addToast('Showtime berhasil diaktifkan kembali', 'success');
  }

  return (
    <div>
      {confirmDisable && (
        <ConfirmModal
          title="Nonaktifkan Showtime"
          message="Showtime ini akan dinonaktifkan dan tidak akan muncul di halaman pemesanan pelanggan. Lanjutkan?"
          danger
          onConfirm={handleDisable}
          onCancel={function(){ setConfirmDisable(null); }}
        />
      )}
      {blockMsg && (
        <Modal title="Tidak Dapat Dinonaktifkan" onClose={function(){ setBlockMsg(''); }}
          actions={<button className="button button-primary" onClick={function(){ setBlockMsg(''); }}>Mengerti</button>}>
          <InfoBanner type="error">{blockMsg}</InfoBanner>
        </Modal>
      )}
      <PageHeader
        title="Daftar Showtime"
        subtitle="Kelola jadwal tayang seluruh studio"
        actions={
          <button className="button button-primary" onClick={function(){ navigate('create-showtime'); }}>
            <Icon name="plus" size={14} /> Jadwalkan Showtime
          </button>
        }
      />
      <div className="filter-bar">
        <select className="form-control" style={{ width:'auto', minWidth:180 }} value={filterMovie} onChange={function(e){ setFilterMovie(e.target.value); }}>
          <option value="">Semua Film</option>
          {movies.map(function(m){ return <option key={m.id} value={m.id}>{m.title}</option>; })}
        </select>
        <div className="filter-chips">
          {[['all','Semua'],['active','Aktif'],['inactive','Nonaktif']].map(function(opt){
            return <button key={opt[0]} className={'filter-chip'+(filterActive===opt[0]?' active':'')} onClick={function(){ setFilterActive(opt[0]); }}>{opt[1]}</button>;
          })}
        </div>
      </div>
      {filtered.length === 0
        ? <EmptyState icon="calendar" title="Tidak ada showtime" desc="Buat jadwal baru dengan tombol di atas." />
        : (
          <div className="card">
            <div className="table-wrapper">
              <table>
                <thead><tr>
                  <th>Film</th><th>Studio</th><th>Mulai</th><th>Selesai</th>
                  <th>Harga</th><th>Status</th><th>Tiket</th><th>Aksi</th>
                </tr></thead>
                <tbody>
                  {filtered.map(function(st){
                    var stats = getShowtimeStats(st.id);
                    return (
                      <tr key={st.id}>
                        <td>
                          <div style={{ fontWeight:600, fontSize:13 }}>{st.movie.title}</div>
                          <div style={{ fontSize:11, color:'var(--text-3)' }}>{st.movie.theme.name} · {st.movie.age_rating}</div>
                        </td>
                        <td>
                          <div style={{ fontWeight:600 }}>{st.studio.name}</div>
                          <div style={{ fontSize:11, color:'var(--text-3)' }}>{st.studio.studio_type.name}</div>
                        </td>
                        <td>
                          <div style={{ fontFamily:'var(--font-mono)', fontWeight:700 }}>{fmtTime(st.start_at)}</div>
                          <div style={{ fontSize:11, color:'var(--text-3)' }}>{window.fmtDate(st.start_at)}</div>
                        </td>
                        <td style={{ fontFamily:'var(--font-mono)', color:'var(--text-2)' }}>{fmtTime(st.end_at)}</td>
                        <td style={{ fontWeight:700, color:'var(--red)' }}>{fmtCurrency(st.price)}</td>
                        <td><StatusBadge status={st.is_active ? 'active' : 'inactive'} label={st.is_active ? 'Aktif' : 'Nonaktif'} /></td>
                        <td>
                          <div style={{ display:'flex', flexDirection:'column', gap:2, fontSize:12 }}>
                            {stats.held > 0     && <span style={{ color:'var(--s-amber)' }}>Held: {stats.held}</span>}
                            {stats.confirmed > 0 && <span style={{ color:'var(--s-green)' }}>Confirmed: {stats.confirmed}</span>}
                            {stats.printed > 0  && <span style={{ color:'var(--s-purple)' }}>Printed: {stats.printed}</span>}
                            {stats.held===0 && stats.confirmed===0 && stats.printed===0 && <span style={{ color:'var(--text-3)' }}>—</span>}
                          </div>
                        </td>
                        <td>
                          <div style={{ display:'flex', gap:4 }}>
                            <button className="button-icon" title="Detail" onClick={function(){ navigate('showtime-detail', { showtimeId:st.id }); }}>
                              <Icon name="eye" size={14} />
                            </button>
                            {st.is_active
                              ? <button className="button-icon" title="Nonaktifkan" onClick={function(){ tryDisable(st); }}
                                  style={{ color:'var(--s-red)', borderColor:'var(--s-red-bg)' }}>
                                  <Icon name="ban" size={14} />
                                </button>
                              : <button className="button-icon" title="Aktifkan kembali" onClick={function(){ handleEnable(st.id); }}
                                  style={{ color:'var(--s-green)', borderColor:'var(--s-green-bg)' }}>
                                  <Icon name="checkCircle" size={14} />
                                </button>
                            }
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )
      }
    </div>
  );
}

/* ── Create Showtime — 3-Step Visual Wizard ──────── */
function CreateShowtime() {
  var { movies, studios, showtimes, createShowtime, navigate, fmtCurrency } = useApp();
  var [step,         setStep]         = React.useState(1);
  var [selMovie,     setSelMovie]     = React.useState(null);
  var [selDate,      setSelDate]      = React.useState((new Date()).toISOString().slice(0,10));
  var [calYear,      setCalYear]      = React.useState((new Date()).getFullYear());
  var [calMonth,     setCalMonth]     = React.useState((new Date()).getMonth());
  var [selStudio,    setSelStudio]    = React.useState(null);
  var [selStartMin,  setSelStartMin]  = React.useState(null);
  var [price,        setPrice]        = React.useState('');
  var [priceError,   setPriceError]   = React.useState('');
  var [hoverInfo,    setHoverInfo]    = React.useState(null);

  var activeMovies  = movies.filter(function(m){ return m.is_active; });
  var activeStudios = studios.filter(function(s){ return s.is_active; });
  var today         = (new Date()).toISOString().slice(0,10);

  var THEME_BG = { 'Drama':'#4c1d95','Sci-Fi':'#1e3a8a','Horror':'#7f1d1d','Family':'#14532d','Documentary':'#713f12','Action':'#7c2d12','Romance':'#831843' };
  var MONTH_NAMES = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

  /* ── data helpers ── */
  var dateShowtimes = React.useMemo(function(){
    return showtimes.filter(function(st){ return st.start_at.slice(0,10)===selDate && st.is_active; });
  }, [showtimes, selDate]);

  function getOccupied(studioId) {
    return dateShowtimes
      .filter(function(st){ return st.studio.id===studioId; })
      .map(function(st){
        var s=new Date(st.start_at), e=new Date(st.end_at);
        return { startMin:s.getHours()*60+s.getMinutes(), endMin:e.getHours()*60+e.getMinutes(), title:st.movie.title };
      });
  }

  function checkConflict(studioId, startMin, durMin) {
    return getOccupied(studioId).some(function(sl){ return startMin < sl.endMin && startMin+durMin > sl.startMin; });
  }

  function pad2(n){ return String(n).padStart(2,'0'); }
  function minsToTime(m){ return pad2(Math.floor((m<0?m+1440:m)/60)%24)+':'+pad2(((m%60)+60)%60); }

  var durMin    = selMovie ? selMovie.runtime_minutes : 0;
  var selEndMin = selStartMin!==null ? selStartMin+durMin : null;
  var conflict  = selStudio && selStartMin!==null ? checkConflict(selStudio.id, selStartMin, durMin) : false;
  var startAt   = selDate && selStartMin!==null ? selDate+'T'+minsToTime(selStartMin) : '';

  /* ── handlers ── */
  function clickTimeline(studio, e) {
    var rect = e.currentTarget.getBoundingClientRect();
    var pct  = Math.max(0, Math.min(1, (e.clientX-rect.left)/rect.width));
    var raw  = Math.round(pct*1440/15)*15;
    setSelStudio(studio);
    setSelStartMin(Math.min(raw, Math.max(0, 1440-durMin)));
    if (!price) setPrice(String(studio.studio_type.base_price));
  }

  function hoverTimeline(studioId, e) {
    var rect = e.currentTarget.getBoundingClientRect();
    var pct  = Math.max(0, Math.min(1, (e.clientX-rect.left)/rect.width));
    setHoverInfo({ studioId, min: Math.round(pct*1440/15)*15 });
  }

  function handleSave() {
    if (!price || Number(price)<=0) { setPriceError('Harga tiket wajib diisi'); return; }
    if (conflict) return;
    createShowtime({ movie:selMovie, studio:selStudio, start_at:startAt, price:Number(price) });
    navigate('showtimes');
  }

  /* ── calendar ── */
  function buildCal() {
    var dim   = new Date(calYear, calMonth+1, 0).getDate();
    var first = (new Date(calYear, calMonth, 1).getDay()+6)%7;
    var days  = [], prev = new Date(calYear, calMonth, 0).getDate();
    for (var i=first-1; i>=0; i--) days.push({ d:prev-i, curr:false, date:null });
    for (var d=1; d<=dim; d++) days.push({ d, curr:true, date:calYear+'-'+pad2(calMonth+1)+'-'+pad2(d) });
    while (days.length%7) days.push({ d:days.length-first-dim+1, curr:false, date:null });
    return days;
  }

  /* ── step indicator ── */
  function renderStepper() {
    var labels = ['Film','Tanggal','Studio & Waktu'];
    return (
      <div style={{ display:'flex', alignItems:'center', marginBottom:32 }}>
        {labels.map(function(lbl, i){
          var n=i+1, done=step>n, active=step===n;
          return (
            <React.Fragment key={n}>
              <div style={{ display:'flex', alignItems:'center', gap:8, cursor:done?'pointer':'default' }}
                onClick={function(){ if(done) setStep(n); }}>
                <div style={{
                  width:28, height:28, borderRadius:'50%', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center',
                  background:(done||active)?'var(--red)':'var(--bg)', fontWeight:700, fontSize:12,
                  border:(!done&&!active)?'2px solid var(--border)':'none', color:(done||active)?'white':'var(--text-3)',
                }}>
                  {done ? <Icon name="check" size={12} color="white" /> : n}
                </div>
                <span style={{ fontSize:13, fontWeight:active?700:done?600:400, color:(active||done)?'var(--text-1)':'var(--text-3)' }}>{lbl}</span>
              </div>
              {i<labels.length-1 && <div style={{ flex:1, height:2, background:step>n?'var(--red)':'var(--border-lt)', margin:'0 10px', borderRadius:1 }}></div>}
            </React.Fragment>
          );
        })}
      </div>
    );
  }

  /* ── step 1: film selection ── */
  function renderStep1() {
    return (
      <div>
        <div style={{ marginBottom:20 }}>
          <div style={{ fontSize:20, fontWeight:800, marginBottom:4 }}>Pilih Film</div>
          <div style={{ fontSize:13, color:'var(--text-3)' }}>Pilih film yang akan dijadwalkan</div>
        </div>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(168px,1fr))', gap:12 }}>
          {activeMovies.map(function(m){
            var bg = THEME_BG[m.theme.name] || '#1a1410';
            return (
              <button key={m.id}
                onClick={function(){ setSelMovie(m); setStep(2); }}
                className="movie-wizard-card"
                style={{ background:'linear-gradient(160deg,'+bg+'CC,'+bg+')', border:'none', borderRadius:12,
                  padding:0, cursor:'pointer', height:200, display:'flex', flexDirection:'column', justifyContent:'flex-end',
                  overflow:'hidden', position:'relative', textAlign:'left' }}>
                <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', opacity:0.07, pointerEvents:'none' }}>
                  <Icon name="film" size={80} color="white" />
                </div>
                <div style={{ position:'relative', padding:'12px 14px 14px',
                  background:'linear-gradient(to top,rgba(0,0,0,0.84) 0%,transparent 100%)' }}>
                  <div style={{ fontSize:9, fontWeight:700, letterSpacing:'0.1em', color:'#c89b3c', textTransform:'uppercase', marginBottom:4 }}>{m.theme.name}</div>
                  <div style={{ fontSize:15, fontWeight:800, color:'white', lineHeight:1.2, marginBottom:8, textWrap:'pretty' }}>{m.title}</div>
                  <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                    <span style={{ fontSize:10, background:'rgba(255,255,255,0.18)', color:'white', padding:'2px 7px', borderRadius:4, fontWeight:600 }}>{m.age_rating}</span>
                    <span style={{ fontSize:10, color:'rgba(255,255,255,0.5)' }}>{m.runtime_minutes} mnt</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  /* ── step 2: date selection ── */
  function renderStep2() {
    var calDays = buildCal();
    return (
      <div style={{ display:'flex', gap:32, alignItems:'flex-start' }}>
        <div>
          <div style={{ marginBottom:20 }}>
            <div style={{ fontSize:20, fontWeight:800, marginBottom:4 }}>Pilih Tanggal</div>
            <div style={{ fontSize:13, color:'var(--text-3)' }}>Pilih tanggal tayang showtime</div>
          </div>
          <div style={{ background:'var(--bg-card)', borderRadius:14, border:'1px solid var(--border-lt)', padding:20, width:280 }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
              <button className="button-icon" onClick={function(){
                if(calMonth===0){setCalMonth(11);setCalYear(calYear-1);}else setCalMonth(calMonth-1);
              }}><Icon name="arrowLeft" size={16}/></button>
              <span style={{ fontWeight:700, fontSize:14 }}>{MONTH_NAMES[calMonth]} {calYear}</span>
              <button className="button-icon" onClick={function(){
                if(calMonth===11){setCalMonth(0);setCalYear(calYear+1);}else setCalMonth(calMonth+1);
              }}><Icon name="arrowRight" size={16}/></button>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', textAlign:'center', marginBottom:6 }}>
              {['Sen','Sel','Rab','Kam','Jum','Sab','Min'].map(function(d){
                return <div key={d} style={{ fontSize:10, fontWeight:600, color:'var(--text-3)', padding:'4px 0' }}>{d}</div>;
              })}
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:2 }}>
              {calDays.map(function(item,i){
                var isToday=item.date===today, isSel=item.date===selDate, isPast=item.date&&item.date<today;
                return (
                  <button key={i} disabled={!item.curr||isPast}
                    onClick={function(){ if(item.date){ setSelDate(item.date); setStep(3); setSelStudio(null); setSelStartMin(null); } }}
                    style={{
                      background:isSel?'var(--red)':isToday?'var(--red-light)':'transparent',
                      color:isSel?'white':(!item.curr||isPast)?'var(--text-3)':isToday?'var(--red)':'var(--text-1)',
                      border:isToday&&!isSel?'1px solid var(--red-border)':'1px solid transparent',
                      borderRadius:7, padding:'7px 0', fontSize:13, fontWeight:(isSel||isToday)?700:400,
                      cursor:(!item.curr||isPast)?'default':'pointer',
                    }}>
                    {item.d}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div style={{ flex:1, paddingTop:52 }}>
          <div style={{ fontSize:11, color:'var(--text-3)', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:8 }}>Film dipilih</div>
          <div style={{ display:'flex', alignItems:'center', gap:12, background:'var(--bg-card)', border:'1px solid var(--border-lt)', borderRadius:12, padding:16, marginBottom:16 }}>
            <div style={{ width:44, height:44, borderRadius:8, background: THEME_BG[selMovie.theme.name]||'var(--red)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <Icon name="film" size={20} color="white" />
            </div>
            <div>
              <div style={{ fontWeight:700, fontSize:15 }}>{selMovie.title}</div>
              <div style={{ fontSize:12, color:'var(--text-3)' }}>{selMovie.theme.name} · {selMovie.runtime_minutes} mnt · {selMovie.age_rating}</div>
            </div>
            <button className="button button-ghost button-sm" style={{ marginLeft:'auto' }} onClick={function(){ setStep(1); }}>Ganti</button>
          </div>
          <InfoBanner type="info">Pilih tanggal untuk melihat ketersediaan studio dan timeline showtime yang sudah ada.</InfoBanner>
        </div>
      </div>
    );
  }

  /* ── step 3: visual timeline ── */
  function renderStep3() {
    var HOUR_MARKS = [0,3,6,9,12,15,18,21,24];
    return (
      <div>
        {/* Header strip */}
        <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:20, flexWrap:'wrap' }}>
          <div>
            <div style={{ fontSize:20, fontWeight:800, marginBottom:2 }}>Pilih Studio &amp; Waktu</div>
            <div style={{ fontSize:13, color:'var(--text-3)' }}>Klik area kosong di timeline untuk menempatkan showtime</div>
          </div>
          <div style={{ marginLeft:'auto', display:'flex', gap:10, alignItems:'center', flexWrap:'wrap' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, background:'var(--bg-card)', border:'1px solid var(--border-lt)', borderRadius:10, padding:'8px 14px' }}>
              <Icon name="film" size={14} color="var(--text-2)"/>
              <span style={{ fontSize:13, fontWeight:600 }}>{selMovie.title}</span>
              <span style={{ fontSize:11, color:'var(--text-3)', marginLeft:4 }}>{durMin} mnt</span>
              <button onClick={function(){ setStep(1); }} style={{ background:'none', border:'none', color:'var(--text-3)', cursor:'pointer', padding:'0 0 0 4px', fontSize:13 }}>×</button>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8, background:'var(--bg-card)', border:'1px solid var(--border-lt)', borderRadius:10, padding:'8px 14px' }}>
              <Icon name="calendar" size={14} color="var(--text-2)"/>
              <span style={{ fontSize:13, fontWeight:600 }}>{selDate}</span>
              <button onClick={function(){ setStep(2); }} style={{ background:'none', border:'none', color:'var(--text-3)', cursor:'pointer', padding:'0 0 0 4px', fontSize:13 }}>×</button>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom:16 }}>
          <div className="card-body" style={{ padding:'20px 20px 16px' }}>
            {/* Legend */}
            <div style={{ display:'flex', gap:16, marginBottom:16, fontSize:11, color:'var(--text-3)', alignItems:'center' }}>
              <div style={{ display:'flex', alignItems:'center', gap:5 }}>
                <div style={{ width:12, height:12, borderRadius:3, background:'#1a1410' }}></div>Sudah dijadwalkan
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:5 }}>
                <div style={{ width:12, height:12, borderRadius:3, background:'var(--red)' }}></div>Showtime baru
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:5 }}>
                <div style={{ width:12, height:12, borderRadius:3, background:'var(--s-red)', opacity:0.8 }}></div>Konflik
              </div>
            </div>

            {/* Hour ruler */}
            <div style={{ display:'flex', gap:12, alignItems:'center', marginBottom:4 }}>
              <div style={{ width:108, flexShrink:0 }}></div>
              <div style={{ flex:1, display:'flex', justifyContent:'space-between' }}>
                {HOUR_MARKS.map(function(h){
                  return <span key={h} style={{ fontSize:9, color:'var(--text-3)', fontFamily:'var(--font-mono)' }}>{pad2(h)}</span>;
                })}
              </div>
              <div style={{ width:64 }}></div>
            </div>

            {/* Studio timeline rows */}
            {activeStudios.map(function(studio){
              var occupied   = getOccupied(studio.id);
              var isSel      = selStudio && selStudio.id===studio.id;
              var myConflict = isSel && selStartMin!==null && conflict;

              return (
                <div key={studio.id} style={{ display:'flex', alignItems:'center', gap:12, marginBottom:10 }}>
                  {/* Label */}
                  <div style={{ width:108, flexShrink:0 }}>
                    <div style={{ fontSize:12, fontWeight:700, color:'var(--text-1)' }}>{studio.name}</div>
                    <div style={{ fontSize:10, color:'var(--text-3)' }}>{studio.studio_type.name} · {fmtCurrency(studio.studio_type.base_price)}</div>
                  </div>

                  {/* Timeline bar */}
                  <div
                    onClick={function(e){ clickTimeline(studio,e); }}
                    onMouseMove={function(e){ hoverTimeline(studio.id,e); }}
                    onMouseLeave={function(){ setHoverInfo(null); }}
                    style={{
                      flex:1, height:48, background:'var(--bg)', borderRadius:8, position:'relative', cursor:'crosshair',
                      border: isSel ? '2px solid var(--red)' : '2px solid var(--border-lt)',
                      overflow:'hidden', transition:'border-color 150ms',
                    }}>
                    {/* Hour grid lines */}
                    {[3,6,9,12,15,18,21].map(function(h){
                      return <div key={h} style={{ position:'absolute', left:(h/24*100)+'%', top:0, bottom:0, width:1, background:'var(--border-lt)', pointerEvents:'none' }}></div>;
                    })}

                    {/* Occupied blocks */}
                    {occupied.map(function(sl,i){
                      var left=(sl.startMin/1440*100)+'%', wid=((sl.endMin-sl.startMin)/1440*100)+'%';
                      return (
                        <div key={i} style={{ position:'absolute', left, width:wid, top:5, bottom:5,
                          background:'#1a1410', borderRadius:5, display:'flex', alignItems:'center',
                          padding:'0 7px', overflow:'hidden', pointerEvents:'none' }}>
                          <span style={{ fontSize:9, fontWeight:700, color:'rgba(255,255,255,0.65)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{sl.title}</span>
                        </div>
                      );
                    })}

                    {/* Hover ghost */}
                    {hoverInfo && hoverInfo.studioId===studio.id && selMovie && !(isSel && selStartMin!==null) && (function(){
                      var left=(hoverInfo.min/1440*100)+'%', wid=(durMin/1440*100)+'%';
                      return <div style={{ position:'absolute', left, width:wid, top:5, bottom:5, background:'var(--red)', borderRadius:5, opacity:0.2, pointerEvents:'none' }}></div>;
                    })()}

                    {/* Selected block */}
                    {isSel && selStartMin!==null && (function(){
                      var left=(selStartMin/1440*100)+'%', wid=(durMin/1440*100)+'%';
                      return (
                        <div style={{ position:'absolute', left, width:wid, top:5, bottom:5,
                          background: myConflict ? 'var(--s-red)' : 'var(--red)',
                          borderRadius:5, display:'flex', alignItems:'center', padding:'0 8px',
                          overflow:'hidden', pointerEvents:'none', boxShadow:'0 2px 8px rgba(159,29,46,0.35)', zIndex:2 }}>
                          <span style={{ fontSize:9, fontWeight:700, color:'white', whiteSpace:'nowrap' }}>
                            {minsToTime(selStartMin)} – {minsToTime(selStartMin+durMin)}
                          </span>
                        </div>
                      );
                    })()}
                  </div>

                  {/* Seat count */}
                  <div style={{ width:64, textAlign:'right', flexShrink:0 }}>
                    <div style={{ fontSize:12, fontWeight:700, color:'var(--text-2)' }}>{studio.capacity}</div>
                    <div style={{ fontSize:10, color:'var(--text-3)' }}>kursi</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Booking summary panel */}
        {selStudio && selStartMin!==null ? (
          <div className="card" style={{ border:'2px solid '+(conflict?'var(--s-red)':'var(--red)') }}>
            <div className="card-body" style={{ padding:20 }}>
              <div style={{ display:'flex', gap:24, alignItems:'center', flexWrap:'wrap' }}>
                <div style={{ flex:1, minWidth:220 }}>
                  <div style={{ fontSize:10, color:'var(--text-3)', fontWeight:700, textTransform:'uppercase', letterSpacing:'0.09em', marginBottom:6 }}>
                    {selStudio.name} · {selStudio.studio_type.name} · {selDate}
                  </div>
                  <div style={{ fontSize:26, fontWeight:800, color:'var(--text-1)', letterSpacing:'-0.02em', marginBottom:4 }}>
                    {minsToTime(selStartMin)}
                    <span style={{ color:'var(--text-3)', fontWeight:400, margin:'0 8px' }}>→</span>
                    {minsToTime(selStartMin+durMin)}
                    {selStartMin+durMin>1440 && <span style={{ fontSize:11, color:'var(--text-3)', fontWeight:500, marginLeft:8 }}>+1 hari</span>}
                  </div>
                  <div style={{ fontSize:13, color:'var(--text-2)' }}>{selMovie.title} · {durMin} mnt · {selStudio.capacity} kursi</div>
                  {conflict && (
                    <div style={{ marginTop:8, display:'flex', alignItems:'center', gap:6, color:'var(--s-red)', fontSize:12, fontWeight:600 }}>
                      <Icon name="alertTriangle" size={13} color="var(--s-red)" />
                      Waktu bertabrakan dengan showtime lain — pilih slot kosong
                    </div>
                  )}
                </div>
                <div style={{ display:'flex', gap:10, alignItems:'flex-end', flexShrink:0 }}>
                  <div>
                    <label style={{ display:'block', fontSize:10, fontWeight:700, color:'var(--text-3)', textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:6 }}>Harga Tiket (IDR)</label>
                    <input type="number" min="0" className="form-control" value={price}
                      onChange={function(e){ setPrice(e.target.value); setPriceError(''); }}
                      style={{ width:160 }} />
                    {priceError && <div className="form-error" style={{ marginTop:4 }}><Icon name="alertTriangle" size={12}/>{priceError}</div>}
                  </div>
                  <button className="button button-primary button-lg" disabled={conflict} onClick={handleSave}
                    style={{ opacity:conflict?0.4:1, pointerEvents:conflict?'none':'auto' }}>
                    <Icon name="checkCircle" size={15}/> Jadwalkan
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div style={{ textAlign:'center', padding:'40px 0', color:'var(--text-3)' }}>
            <div style={{ width:52, height:52, borderRadius:'50%', background:'var(--bg-card)', border:'1px solid var(--border-lt)', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 12px' }}>
              <Icon name="clock" size={24} color="var(--text-3)"/>
            </div>
            <div style={{ fontSize:14, marginBottom:4 }}>Klik pada baris studio untuk memilih waktu tayang</div>
            <div style={{ fontSize:12, color:'var(--text-3)' }}>Durasi: {durMin} menit · blok akan muncul di timeline</div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Jadwalkan Showtime" back onBack={function(){ navigate('showtimes'); }} />
      {renderStepper()}
      {step===1 && renderStep1()}
      {step===2 && renderStep2()}
      {step===3 && renderStep3()}
    </div>
  );
}

/* ── Showtime Detail ─────────────────────────────── */
function ShowtimeDetail() {
  var { pageParams, showtimes, orders, navigate, toggleShowtime, getShowtimeStats, fmtCurrency, fmtDateTime, fmtTime, addToast } = useApp();
  var [blockMsg, setBlockMsg] = React.useState('');
  var [confirmId, setConfirmId] = React.useState(null);
  var stId = pageParams.showtimeId;
  var st   = showtimes.find(function(s){ return s.id === stId; });
  if (!st) return <EmptyState icon="calendar" title="Showtime tidak ditemukan" />;

  var stats = getShowtimeStats(stId);
  var activeTickets = stats.held + stats.confirmed + stats.printed;

  var stOrders = orders.filter(function(o){ return o.showtime.id === stId; });

  function tryDisable() {
    if (activeTickets > 0) {
      setBlockMsg('Showtime tidak dapat dinonaktifkan karena sudah memiliki tiket aktif (Held: ' + stats.held + ', Confirmed: ' + stats.confirmed + ', Printed: ' + stats.printed + ').');
      return;
    }
    setConfirmId(stId);
  }

  return (
    <div>
      {blockMsg && (
        <Modal title="Tidak Dapat Dinonaktifkan" onClose={function(){ setBlockMsg(''); }}
          actions={<button className="button button-primary" onClick={function(){ setBlockMsg(''); }}>Mengerti</button>}>
          <InfoBanner type="error">{blockMsg}</InfoBanner>
        </Modal>
      )}
      {confirmId && (
        <ConfirmModal
          title={st.is_active ? 'Nonaktifkan Showtime' : 'Aktifkan Showtime'}
          message={st.is_active
            ? 'Showtime akan dinonaktifkan dan tidak muncul di pemesanan pelanggan.'
            : 'Showtime akan diaktifkan kembali dan muncul di pemesanan pelanggan.'}
          danger={st.is_active}
          onConfirm={function(){
            toggleShowtime(stId);
            addToast(st.is_active ? 'Showtime dinonaktifkan' : 'Showtime diaktifkan', 'success');
            setConfirmId(null);
          }}
          onCancel={function(){ setConfirmId(null); }}
        />
      )}
      <PageHeader
        title={st.movie.title}
        subtitle={'Detail Showtime — ' + st.id}
        back onBack={function(){ navigate('showtimes'); }}
        actions={
          <div style={{ display:'flex', gap:8 }}>
            {st.is_active
              ? <button className="button button-danger" onClick={tryDisable}><Icon name="ban" size={14} /> Nonaktifkan</button>
              : <button className="button button-primary" onClick={function(){ setConfirmId(stId); }}><Icon name="checkCircle" size={14} /> Aktifkan</button>
            }
          </div>
        }
      />
      {!st.is_active && (
        <div style={{ marginBottom:16 }}>
          <InfoBanner type="warning">Showtime ini nonaktif dan tidak muncul di halaman pemesanan pelanggan.</InfoBanner>
        </div>
      )}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24 }}>
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div className="card">
            <div className="card-header"><Icon name="film" size={15} /><div className="card-title">Film</div></div>
            <div className="card-body">
              <div className="order-summary-row"><span>Judul</span><span style={{ fontWeight:700 }}>{st.movie.title}</span></div>
              <div className="order-summary-row"><span>Genre</span><span>{st.movie.theme.name}</span></div>
              <div className="order-summary-row"><span>Rating</span><StatusBadge status={st.movie.age_rating} label={st.movie.age_rating} /></div>
              <div className="order-summary-row" style={{ border:'none' }}><span>Durasi</span><span>{st.movie.runtime_minutes} menit</span></div>
            </div>
          </div>
          <div className="card">
            <div className="card-header"><Icon name="layers" size={15} /><div className="card-title">Studio &amp; Jadwal</div></div>
            <div className="card-body">
              <div className="order-summary-row"><span>Studio</span><span>{st.studio.name}</span></div>
              <div className="order-summary-row"><span>Tipe</span><span>{st.studio.studio_type.name}</span></div>
              <div className="order-summary-row"><span>Kapasitas</span><span>{st.studio.capacity} kursi</span></div>
              <div className="order-summary-row"><span>Waktu Mulai</span><span style={{ fontFamily:'var(--font-mono)', fontWeight:700 }}>{fmtTime(st.start_at)}</span></div>
              <div className="order-summary-row"><span>Waktu Selesai</span><span style={{ fontFamily:'var(--font-mono)' }}>{fmtTime(st.end_at)}</span></div>
              <div className="order-summary-row"><span>Tanggal</span><span>{window.fmtDate(st.start_at)}</span></div>
              <div className="order-summary-row" style={{ border:'none' }}><span>Harga</span><span style={{ fontWeight:800, color:'var(--red)', fontSize:16 }}>{fmtCurrency(st.price)}</span></div>
            </div>
          </div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:12 }}>
            <div className="stat-card">
              <div className="stat-label">Held</div>
              <div className="stat-value" style={{ color:'var(--s-amber)' }}>{stats.held}</div>
              <div className="stat-sub">Ditahan</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Confirmed</div>
              <div className="stat-value" style={{ color:'var(--s-green)' }}>{stats.confirmed}</div>
              <div className="stat-sub">Dikonfirmasi</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Printed</div>
              <div className="stat-value" style={{ color:'var(--s-purple)' }}>{stats.printed}</div>
              <div className="stat-sub">Tercetak</div>
            </div>
          </div>
          {activeTickets > 0 && (
            <InfoBanner type="warning">
              Showtime ini memiliki {activeTickets} tiket aktif. Tidak dapat dinonaktifkan sampai semua tiket aktif diselesaikan atau dibatalkan.
            </InfoBanner>
          )}
          <div className="card">
            <div className="card-header"><div className="card-title">Pesanan Terkait ({stOrders.length})</div></div>
            <div className="card-body" style={{ padding:0 }}>
              {stOrders.length === 0
                ? <div style={{ padding:16, color:'var(--text-3)', fontSize:13 }}>Belum ada pesanan</div>
                : stOrders.slice(0,8).map(function(o){
                    return (
                      <div key={o.id} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 16px', borderBottom:'1px solid var(--border-lt)' }}>
                        <span className="font-mono" style={{ fontSize:12, color:'var(--text-2)' }}>{o.number}</span>
                        <StatusBadge status={o.status} />
                        <span style={{ fontSize:12, color:'var(--text-3)', flex:1 }}>{o.tickets.length} tiket</span>
                        <button className="button-icon" onClick={function(){ navigate('order-detail', { orderId:o.id }); }}>
                          <Icon name="eye" size={13} />
                        </button>
                      </div>
                    );
                  })
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { SchedulerShowtimes, CreateShowtime, ShowtimeDetail });
